<?php

return [
    'site_title' => 'MVP',

];
