
<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.show')); ?> <?php echo e(trans('cruds.event.title')); ?>

    </div>

    <div class="card-body">
        <div class="form-group">
            <table class="table table-bordered table-striped">
                <tbody>
                    <tr>
                        <th>
                            Id
                        </th>
                        <td>
                        <?php echo e($events->id); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                        Title
                        </th>
                        <td>
                        <?php echo e($events->title); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            Status
                        </th>
                        <td>
                        <?php echo e($events->status ? "Active": "Inactive" ?? ''); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            Slug
                        </th>
                        <td>
                        <?php echo e($events->slug); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            Image
                        </th>
                        <td>
                        <a href="<?php echo e(asset($events->image)); ?>" target="_blank"><img src="<?php echo e(asset($events->image)); ?>" width="30px" height="30px"/></a>
                        </td>
                    </tr>
                    <tr>
                        <th>
                            Description
                        </th>
                        <td>
                        <?php echo e($events->description); ?>

                        </td>
                    </tr>
                </tbody>
            </table>
            <div class="form-group">
                <a class="btn btn-default" href="<?php echo e(route('admin.events.index')); ?>">
                    <?php echo e(trans('global.back_to_list')); ?>

                </a>
            </div>
        </div>
    </div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Mvp\resources\views/admin/event/show.blade.php ENDPATH**/ ?>